package com.cleverdevelopers.chattingapplicationinkotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ChatActivity : AppCompatActivity() {
    private lateinit var messageRecyclerView: RecyclerView
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageView

    private lateinit var messageAdapter: MessageAdapter
    private lateinit var messageList: ArrayList<Message>
    private lateinit var databaseRef : DatabaseReference

    var receiverRoom: String? = null
    var senderRoom: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val name = intent.getStringExtra("name")

        val receiver_uid = intent.getStringExtra("uid")
        val sender_uid = FirebaseAuth.getInstance().currentUser?.uid

        databaseRef = FirebaseDatabase.getInstance().getReference()

        // Creating a unique room for sender and receiver in oder for the messages to be private
        senderRoom = sender_uid + receiver_uid
        receiverRoom = receiver_uid + sender_uid

        supportActionBar?.title = name

        messageRecyclerView = findViewById(R.id.recyclerView)
        messageRecyclerView.layoutManager = LinearLayoutManager(this)

        messageInput = findViewById(R.id.messageBox)
        sendButton = findViewById(R.id.sendBtn)

        messageList = ArrayList()
        messageAdapter = MessageAdapter(this, messageList)
        messageRecyclerView.adapter = messageAdapter

        //Displaying of messages
        databaseRef.child("chats")
            .child(senderRoom!!).child("messages")
            .addValueEventListener(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {

                    messageList.clear()

                    for (messageSnapshot in snapshot.children){
                        val message = messageSnapshot.getValue(Message::class.java)
                        messageList.add(message!!)
                    }

                    messageAdapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@ChatActivity, error.toString(), Toast.LENGTH_LONG).show()
                }

            })

        // adding messages to the database
        sendButton.setOnClickListener {
            val message = messageInput.text.toString()
            val messageModel = Message(message, sender_uid)

            messageInput.text = null

            databaseRef.child("chats").child(senderRoom!!)
                .child("messages")
                .push().setValue(messageModel).addOnSuccessListener {
                    // Do same for receiver
                    databaseRef.child("chats").child(receiverRoom!!)
                        .child("messages")
                        .push().setValue(messageModel)
                }
        }
    }
}