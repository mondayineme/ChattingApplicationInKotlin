package com.cleverdevelopers.chattingapplicationinkotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class RegistrationActivity : AppCompatActivity() {
    private lateinit var edtNameReg: EditText
    private lateinit var edtEmailReg: EditText
    private lateinit var edtPasswordReg: EditText
    private lateinit var btnRegister: Button
    private lateinit var txt_goto_login: TextView
    private lateinit var databaseRef : DatabaseReference

    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        supportActionBar!!.hide()

        mAuth = FirebaseAuth.getInstance()
        databaseRef = FirebaseDatabase.getInstance().getReference()

        edtNameReg = findViewById(R.id.reg_name)
        edtEmailReg = findViewById(R.id.reg_email)
        edtPasswordReg = findViewById(R.id.reg_password)
        txt_goto_login = findViewById(R.id.txt_goto_login)
        btnRegister = findViewById(R.id.btn_register)

        txt_goto_login.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        btnRegister.setOnClickListener {
            val name_reg = edtNameReg.text.toString()
            val email_reg = edtEmailReg.text.toString()
            val password_reg = edtPasswordReg.text.toString()

            register(name_reg, email_reg, password_reg)
        }
    }

    private fun register(regName: String, emailReg: String, passwordReg: String) {
        mAuth.createUserWithEmailAndPassword(emailReg, passwordReg).addOnCompleteListener(this){task->
            if (task.isSuccessful){

                val uid = mAuth.currentUser!!.uid
                addUserToRealTimeDatabase(regName, emailReg, uid)

                val intent = Intent(this, MainActivity::class.java)
                Toast.makeText(this, "Registration successful...", Toast.LENGTH_LONG).show()
                startActivity(intent)
                finish()
            }else{
                Toast.makeText(this, "Error Occurred!", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun addUserToRealTimeDatabase(regName: String, emailReg: String, uid: String?) {
        val user = User(regName, emailReg, uid)
        databaseRef.child("users").child(uid!!).setValue(user)
    }
}